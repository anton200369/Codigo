import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;

public class tcpmpcli{
    public static void main(String[] args) throws IOException {

        if (args.length != 2) {
            if(args.length !=3){
            System.out.println("Wrong format. Correct: tcmptcli ip_server_address server_port_number");

            System.out.println("Ex: tcpcli 127.0.0.1 8888");
            
            }
            
        }
        boolean select= false;
        if (args.length == 3){
            if(args[2].equals("-u"))
            select=true;
        }






        
        if(select){
            int serverportnum= Integer.parseInt(args[1]);
            InetSocketAddress direccserver = new InetSocketAddress(InetAddress.getByName(args[0]), serverportnum);
            byte[] opString= new byte[128];
        DatagramSocket infoforserver= new DatagramSocket();

        DatagramPacket serverdat= new DatagramPacket(opString,opString.length);
        DatagramPacket receiveddata = null;

        BufferedReader scan = new BufferedReader(new InputStreamReader(System.in));

                while (true) {

                    System.out.println("Please enter the operation in infix notation, with spaces:");
                    String opstring = scan.readLine();
                    opstring.replaceAll(" ", "");

                    if(opstring.compareTo("QUIT")==0){

                        break;
                        }

                    String[] elements = opstring.split("\\s+");
                    int operator = 0;
                    int num0=0;
                    int num1 = Integer.parseInt(elements[0]);
                    int num2=0;
                    if(elements.length==3)num2=Integer.parseInt(elements[2]);
                    int length = 2;
                        
                    if(num1>=-128 && num1<=127&&num2>=-128&&num2<=127){
                    
                    if (elements.length == 3) {

                        
                        switch (elements[1]) {
                            case "+":
                                operator = 1;
                                break;
                            case "-":
                                operator = 2;
                                break;
                            case "*":
                                operator = 3;
                                break;
                            case "/":
                                operator = 4;
                                break;
                            case "%":
                                operator = 5;
                                break;
                            default:
                                System.out.println("Wrong operator");
                                
                                continue;
                        }
                    
                    
                    } else if (elements.length == 2 && elements[1].equals("!")) {

                        length = 1;
                        operator = 6;
                        num0 = Integer.parseInt(elements[0]);

                    } else {
                        System.out.println("Wrong format");
                        continue;
                    }
                }else System.out.println("Operators have to be within the range [-128, 127]");
                




                    byte[] operation=null;
                    byte[] response = new byte[128];
                    
                    byte[] finalresult = new byte[8];

                    if (length == 2) {
                        num2 = Integer.parseInt(elements[2]);
                        
                        operation = new byte[] { (byte) operator, (byte) length, (byte) num1, (byte) num2 };
                        receiveddata = new DatagramPacket(operation, operation.length, direccserver);
                        
                    } else if(length==1){
                        operation = new byte[] { (byte) operator, (byte) length, (byte) num0 };
                        receiveddata = new DatagramPacket(operation, operation.length, direccserver);
                        
                    }
                    
                    infoforserver.send(receiveddata);
                    infoforserver.receive(serverdat);


                    int lengthv = (int) response[1];
                    int errorv = (int) response[2];
                    

                    if(lengthv==10){


                    System.arraycopy(response, 4, finalresult, 0, finalresult.length);
                    long resultplusacc = (ByteBuffer.wrap(finalresult)).getLong();

                    System.out.println("The value of the accumulator is: " + resultplusacc);
                        continue;
                    
                }

                  if(errorv==16){

                    System.arraycopy(response, 4, finalresult, 0, finalresult.length);
                long resultplusacc2 = (ByteBuffer.wrap(finalresult)).getLong();

                System.out.println("The value of the accumulator is: " + resultplusacc2);


                    byte[] finalresult2 = new byte[response[13]];
                System.arraycopy(response, 13, finalresult2, 0, finalresult2.length);

                String acc2 = new String(finalresult2);

                System.out.println(acc2);


                }

                else if(errorv==11){

                    System.arraycopy(response, 6 + response[3], finalresult, 0, finalresult.length);
                    long resultplusacc = (ByteBuffer.wrap(finalresult)).getLong();

                    System.out.println("The value of the accumulator is: " + resultplusacc);

                    


                        byte[] finalresult2 = new byte[response[4]];
                        System.arraycopy(response, 4, finalresult2, 0, finalresult2.length);

                    String acc2 = new String(finalresult2);

                    System.out.println(acc2);

                }
                }
        }
        
        
        
        else{

        
            Socket fullsocket = new Socket();
            fullsocket.connect(new InetSocketAddress(args[0], Integer.parseInt(args[1])));
            OutputStream opforserver = new DataOutputStream(fullsocket.getOutputStream());
            InputStream resultforclient = new DataInputStream(fullsocket.getInputStream());
            BufferedReader scan = new BufferedReader(new InputStreamReader(System.in));

            try{
                while (true) {

                    System.out.println("Please enter the operation in infix notation, with spaces:");
                    String opstring = scan.readLine();
                    opstring.replaceAll(" ", "");

                    if(opstring.compareTo("QUIT")==0){
                        opforserver.close();
                        resultforclient.close();
                        fullsocket.close(); 
                        return;
                        }

                    String[] elements = opstring.split("\\s+");
                    int operator = 0;
                    int num0=0;
                    int num1 = Integer.parseInt(elements[0]);
                    int num2=0;
                    if(elements.length==3)num2=Integer.parseInt(elements[2]);
                    int length = 2;
                        
                    if(num1>=-128 && num1<=127&&num2>=-128&&num2<=127){
                    
                    if (elements.length == 3) {

                        
                        switch (elements[1]) {
                            case "+":
                                operator = 1;
                                break;
                            case "-":
                                operator = 2;
                                break;
                            case "*":
                                operator = 3;
                                break;
                            case "/":
                                operator = 4;
                                break;
                            case "%":
                                operator = 5;
                                break;
                            default:
                                System.out.println("Wrong operator");
                                
                                continue;
                        }
                    
                    
                    } else if (elements.length == 2 && elements[1].equals("!")) {

                        length = 1;
                        operator = 6;
                        num0 = Integer.parseInt(elements[0]);

                    } else {
                        System.out.println("Wrong format");
                        continue;
                    }
                }else System.out.println("Operators have to be within the range [-128, 127]");
                




                    byte[] operation=null;
                    byte[] response = new byte[128];
                    
                    byte[] finalresult = new byte[8];

                    if (length == 2) {
                        num2 = Integer.parseInt(elements[2]);
                        
                        operation = new byte[] { (byte) operator, (byte) length, (byte) num1, (byte) num2 };
                        
                    } else if(length==1){
                        operation = new byte[] { (byte) operator, (byte) length, (byte) num0 };
                        
                    }
                    
                    opforserver.write(operation);
                    resultforclient.read(response);
                    int lengthv = (int) response[1];
                    int errorv = (int) response[2];
                    

                    if(lengthv==10){


                    System.arraycopy(response, 4, finalresult, 0, finalresult.length);
                    long resultplusacc = (ByteBuffer.wrap(finalresult)).getLong();

                    System.out.println("The value of the accumulator is: " + resultplusacc);
                        continue;
                    
                }

                  if(errorv==16){

                    System.arraycopy(response, 4, finalresult, 0, finalresult.length);
                long resultplusacc2 = (ByteBuffer.wrap(finalresult)).getLong();

                System.out.println("The value of the accumulator is: " + resultplusacc2);


                    byte[] finalresult2 = new byte[response[13]];
                System.arraycopy(response, 13, finalresult2, 0, finalresult2.length);

                String acc2 = new String(finalresult2);

                System.out.println(acc2);


                }

                else if(errorv==11){

                    System.arraycopy(response, 6 + response[3], finalresult, 0, finalresult.length);
                    long resultplusacc = (ByteBuffer.wrap(finalresult)).getLong();

                    System.out.println("The value of the accumulator is: " + resultplusacc);

                    


                        byte[] finalresult2 = new byte[response[4]];
                        System.arraycopy(response, 4, finalresult2, 0, finalresult2.length);

                    String acc2 = new String(finalresult2);

                    System.out.println(acc2);




                };

           
            }

        }    catch(Exception e){
            e.printStackTrace();
            opforserver.close();
            resultforclient.close();
            fullsocket.close();
            
        }
    }
























































    }

}

