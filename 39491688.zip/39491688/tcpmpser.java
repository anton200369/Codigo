
import java.util.*;
import java.net.*;
import java.nio.Buffer;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.nio.channels.SelectionKey;
import java.util.Set;

public class tcpmpser {


    public static void main (String args[])throws Exception{
        if(args.length!=1){
            System.out.println("Wrong format. Correct : tcpmpser port_number");
            return;
        }


        DatagramChannel dtc = DatagramChannel.open();
        dtc.bind(new InetSocketAddress(Integer.parseInt(args[0])));
        Selector sel= Selector.open();
        dtc.configureBlocking(false);
        dtc.register(sel,SelectionKey.OP_READ);
        dtc.keyFor(sel).attach(Long.valueOf(0));




        ServerSocketChannel ssc= ServerSocketChannel.open();
        ssc.configureBlocking(false);
        ssc.bind(new InetSocketAddress(Integer.parseInt(args[0])));
        ssc.register(sel, SelectionKey.OP_ACCEPT);
        

        while(true){ 


            sel.select();
            Set<SelectionKey> kset= sel.selectedKeys();
             
            Iterator<SelectionKey> iter= kset.iterator();

            SelectionKey key = iter.next();




            if(key.isAcceptable()){

                SocketChannel sc= ((ServerSocketChannel) key.channel()).accept();

                if (sc == null) {
                    key = iter.next();
                }
                else{
                sc.configureBlocking(false);

                SelectionKey readkey= sc.register(sel, SelectionKey.OP_READ);

                readkey.attach(Long.valueOf(0));
                }


            }

            if(key.isReadable()){

                SelectableChannel scread= key.channel();

                
                try{

                if(scread instanceof DatagramChannel){

                    DatagramChannel dcr= (DatagramChannel) scread;

                    ByteBuffer opsend;      //result of operation.
                    ByteBuffer data= ByteBuffer.allocate(4);
                byte[] expression= data.array() ; 
                SocketAddress datatochannel = dcr.receive(data);
                int bytestochannel= dcr.read(data);
                long[] result;
                long acc= (long) key.attachment();
                if(bytestochannel <=0){
                    dcr.close();
                    key.cancel();
                    continue;
                }
            
                
                System.out.println("IP ADDRESS AND PORT NUMBER:" + datatochannel);


                    result=calcu(expression,acc);
                    

                    if(result[1]==1){   //if an error is detected
                        
                        String msg= "Error: Division by 0";
                    opsend=ByteBuffer.allocate(14+msg.length());
                    opsend.put(Integer.valueOf(10).byteValue());
                    opsend.put(Integer.valueOf(14+msg.length()).byteValue());
                    opsend.put(Integer.valueOf(11).byteValue());
                    opsend.put(Integer.valueOf(msg.length()).byteValue());
                    opsend.put(msg.getBytes(),0,msg.length());
                    opsend.put(Integer.valueOf(16).byteValue());
                    opsend.put(Integer.valueOf(8).byteValue());
                    long i= result[0];
                    opsend.putLong(i);
                    opsend.flip();
                    dcr.send(data, datatochannel);
                    

                        break;}

                        if(result[1]==2){   //if an error is detected
                        
                            String msg= "Overflow detected";
                        opsend=ByteBuffer.allocate(14+msg.length());
                        opsend.put(Integer.valueOf(10).byteValue());
                        opsend.put(Integer.valueOf(14+msg.length()).byteValue());
                        opsend.put(Integer.valueOf(11).byteValue());
                        opsend.put(Integer.valueOf(msg.length()).byteValue());
                        opsend.put(msg.getBytes(),0,msg.length());
                        opsend.put(Integer.valueOf(16).byteValue());
                        opsend.put(Integer.valueOf(8).byteValue());
                        long i= result[0];
                        opsend.putLong(i);
                        opsend.flip();
                        dcr.send(data, datatochannel);
    
                            break;
                    }
                    
                    if(result[1]==3){   //if an error is detected
                        
                        String msg= "Error: Negative factorial";
                    opsend=ByteBuffer.allocate(14+msg.length());
                    opsend.put(Integer.valueOf(10).byteValue());
                    opsend.put(Integer.valueOf(14+msg.length()).byteValue());
                    opsend.put(Integer.valueOf(11).byteValue());
                    opsend.put(Integer.valueOf(msg.length()).byteValue());
                    opsend.put(msg.getBytes(),0,msg.length());
                    opsend.put(Integer.valueOf(16).byteValue());
                    opsend.put(Integer.valueOf(8).byteValue());
                    long i= result[0];
                    opsend.putLong(i);
                    opsend.flip();
                    dcr.send(data, datatochannel);

                        break;
                    }
                        
                        else{
            
                    opsend=ByteBuffer.allocate(12);
                    opsend.put(Integer.valueOf(10).byteValue());
                    opsend.put(1,Integer.valueOf(10).byteValue());
                    opsend.put(2,Integer.valueOf(16).byteValue());
                    opsend.put(3,Integer.valueOf(8).byteValue());
                    opsend.putLong(4,result[0]);
                    opsend.flip();
                    dcr.write(opsend);
                    key.attach(Long.valueOf(result[0]));
                        }
                    iter.remove();

                    
                }










                SocketChannel scr= (SocketChannel) scread;
                ByteBuffer data= ByteBuffer.allocate(4);
                int bytestochannel= scr.read(data);

                if(bytestochannel <=0){
                    scr.close();
                    key.cancel();
                    continue;
                }
                ByteBuffer opsend;      //result of operation.

                long[] result;
                long acc= (long) key.attachment();

            
                    System.out.println("IP ADDRESS AND PORT NUMBER:" +scr.getRemoteAddress());



                    result=calcu(data.array(),acc);

                    

                    if(result[1]==1){   //if an error is detected
                        
                        String msg= "Error: Division by 0";
                    opsend=ByteBuffer.allocate(14+msg.length());
                    opsend.put(Integer.valueOf(10).byteValue());
                    opsend.put(Integer.valueOf(14+msg.length()).byteValue());
                    opsend.put(Integer.valueOf(11).byteValue());
                    opsend.put(Integer.valueOf(msg.length()).byteValue());
                    opsend.put(msg.getBytes(),0,msg.length());
                    opsend.put(Integer.valueOf(16).byteValue());
                    opsend.put(Integer.valueOf(8).byteValue());
                    long i= result[0];
                    opsend.putLong(i);
                    opsend.flip();
                    scr.write(opsend);
                    

                        break;
                    }

                        if(result[1]==2){   //if an error is detected
                        
                            String msg= "Overflow detected";
                        opsend=ByteBuffer.allocate(14+msg.length());
                        opsend.put(Integer.valueOf(10).byteValue());
                        opsend.put(Integer.valueOf(14+msg.length()).byteValue());
                        opsend.put(Integer.valueOf(11).byteValue());
                        opsend.put(Integer.valueOf(msg.length()).byteValue());
                        opsend.put(msg.getBytes(),0,msg.length());
                        opsend.put(Integer.valueOf(16).byteValue());
                        opsend.put(Integer.valueOf(8).byteValue());
                        long i= result[0];
                        opsend.putLong(i);
                        opsend.flip();
                        scr.write(opsend);
                    }
                    
                    if(result[1]==3){   //if an error is detected
                        
                        String msg= "Error: Negative factorial";
                    opsend=ByteBuffer.allocate(14+msg.length());
                    opsend.put(Integer.valueOf(10).byteValue());
                    opsend.put(Integer.valueOf(14+msg.length()).byteValue());
                    opsend.put(Integer.valueOf(11).byteValue());
                    opsend.put(Integer.valueOf(msg.length()).byteValue());
                    opsend.put(msg.getBytes(),0,msg.length());
                    opsend.put(Integer.valueOf(16).byteValue());
                    opsend.put(Integer.valueOf(8).byteValue());
                    long i= result[0];
                    opsend.putLong(i);
                    opsend.flip();
                    scr.write(opsend);

                    }
                        
                        else{
            
                    opsend=ByteBuffer.allocate(12);
                    opsend.put(Integer.valueOf(10).byteValue());
                    opsend.put(Integer.valueOf(10).byteValue());
                    opsend.put(Integer.valueOf(16).byteValue());
                    opsend.put(Integer.valueOf(8).byteValue());
                    opsend.putLong(result[0]);
                    opsend.flip();
                    scr.write(opsend);
                    key.attach(Long.valueOf(result[0]));

                        }

                    }catch(Exception dontclose){

                return;

                }
            }
        }
    }






    private static long[] calcu(byte[] expression, long acc){
        int num1=Byte.valueOf(expression[2]).intValue(); 
        int num2=Byte.valueOf(expression[3]).intValue();
        int operator= Byte.valueOf(expression[0]).intValue();
        long result=1;
        long[] erroresult;
        long error= 0;
        int overflow=0;
        
        

        switch(operator){

            case 1: 
            
            result=num1+num2; 
            
            System.out.println(num1+"+"+num2+"= "+result);
            
            break;

            case 2: 
            
            result=num1-num2; 
            
            System.out.println(num1+"-"+num2+"= "+result);
            
            break;

            case 3: 
            
            
            result=Math.multiplyExact(num1,num2);
            
            System.out.println(num1+"*"+num2+"= "+result);

            
            break;

            case 4: 
            
            if(num2==0){
                result=0;

                System.out.println(num1+"/"+num2+"= "+result);
           
                    
            }else{  
                
                result=num1/num2; 

                System.out.println(num1+"/"+num2+"= "+result);
            };
                    
            break;

            case 5: 
            
            result=num1%num2; 
            
            System.out.println(num1+"%"+num2+"= "+result);
            
            break;



            case 6: 
            try{

            for(int i=0; i< num1; i++){

                 result=Math.multiplyExact(result,(num1-i));

                    };

                    if(num1>=0)
                    
                    System.out.println(num1+"!"+"= "+result);

                    else result=0;

                } catch (ArithmeticException overfelow) {
                    overflow=1;
                    error=2;

                    System.out.println("Overflow detected");
                }

                    break;




            default: 

            result=0; 
            
            break;
        }

        if(num2==0&&operator==4){ 
            error=1; 
            System.out.println("Error detected: Division by 0");
           
        }
        if(num1<0&&operator==6){ 
            error=3; 
            System.out.println("Error detected: Negative factorial");
           
        }
        if(overflow!=1){
            try{acc=Math.addExact(result, acc);}
            catch(ArithmeticException e){ acc=Long.MAX_VALUE;}
        }
        return erroresult= new long[] {acc, error};

    }

}